package net.finmath.lecture.numericalmethods.montecarlo;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.DoubleUnaryOperator;

import net.finmath.plots.Plot2D;

public class RunningAverageOfIndicatorAnimation {

	public static void main(String[] args) throws Exception {

		//int numberOfPoints = 100;
		for(int numberOfPoints=2; numberOfPoints<=2000; numberOfPoints++) {

			final List<Double> averageValues1 = getRunningAveragesOfIndicator(3 /* omega */, numberOfPoints, 3105 /* seed */);
			final List<Double> averageValues2 = getRunningAveragesOfIndicator(3 /* omega */, numberOfPoints, 1 /* seed */);

			final DoubleUnaryOperator averageFunction1	= x -> averageValues1.get((int)x-1);
			final DoubleUnaryOperator averageFunction2	= x -> averageValues2.get((int)x-1);
			final DoubleUnaryOperator limitValueFunction	= x -> 1.0/6.0;

			final Plot2D plot = new Plot2D(1.0, numberOfPoints, numberOfPoints, new DoubleUnaryOperator[] {
					averageFunction1,
					averageFunction2,
					limitValueFunction
			});

			plot.setTitle("Plot of running average of indicator function (x[i] == \u03C9[j]))");
			plot.setXAxisLabel("n");
			plot.setYAxisLabel("S(n)");
			plot.saveAsPNG(new File("img/RunningAverageOfIndicator-" +
					(numberOfPoints < 1000 ? "0" : "") +
					(numberOfPoints < 100 ? "0" : "") +
					(numberOfPoints < 10 ? "0" : "") +
					numberOfPoints + ".png"), 960, 600);
		}
		//		plot.show();
	}

	private static List<Double> getRunningAveragesOfIndicator(int omega, int numberOfSamples, int seed) {

		final Random random = new Random(seed);

		final List<Double> averages = new ArrayList<>();

		System.out.println("_".repeat(79));
		System.out.println("i" + "\t" + "x[i]" + "\t" + "indctr" + "\t" + "sum" + "\t" + "avg");
		System.out.println("_".repeat(79));

		int sum = 0;
		for(int i=0; i<numberOfSamples; i++) {

			final int drawing = random.nextInt(6)+1;					// integer in { 1,2,3,4,5,6 }

			final int indicator = (drawing == omega) ? 1 : 0;			// indicator function

			sum += indicator;									// sum up

			final double average = ((double)sum)/(i+1);				// calculation the average

			averages.add(average);								// append the value to the list

			System.out.println((i+1) + "\t" + drawing + "\t" + indicator + "\t" + sum + "\t" + average);
		}
		System.out.println();

		return averages;
	}

}
