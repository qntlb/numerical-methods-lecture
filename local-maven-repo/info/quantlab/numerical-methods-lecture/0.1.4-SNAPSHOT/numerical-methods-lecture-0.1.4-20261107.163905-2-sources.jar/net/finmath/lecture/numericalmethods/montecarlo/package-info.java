/**
 * Utilities and examples for Monte Carlo methods used in the numerical methods lecture.
 *
 * <p>Contains small example programs and helper classes illustrating Monte Carlo experiments
 * and integrations used in the lecture material.</p>
 *
 * @author Christian Fries
 */
package net.finmath.lecture.numericalmethods.montecarlo;
