package info.quantlab.interfaces;

public class Runner {

	public static void main(String[] args) {


		final MultiplyerTester tester = new MultiplyerTester();

		final Multiplyer multiplyer = new MyFunnyMultiplyer();
		tester.test(multiplyer);

		final Multiplyer multiplyer2 = new MyOtherMultiplyer();
		tester.test(multiplyer2);
	}

}
