package info.quantlab.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.IntStream;

import net.finmath.randomnumbers.HaltonSequence;
import net.finmath.randomnumbers.MersenneTwister;
import net.finmath.randomnumbers.RandomNumberGenerator1D;

public class MonteCarloIntegrationParalellization2 {

	static double[] areas = new double[] { 1, 2, Math.PI, 4.0/3.0*Math.PI, 2.0/4.0*Math.PI*Math.PI, 8.0/15.0*Math.PI*Math.PI };

	static int[] base = new int[] { 2, 3, 5, 7, 11 , 13 };

	public static void main(String[] args) throws InterruptedException, ExecutionException {

		final int numberOfSamples = 10000000;
		final int dimension = 5;

		final Random random = new Random();
		testHalton1(numberOfSamples, dimension);
		//		testHalton2(numberOfSamples, dimension);
		//		testHalton3(numberOfSamples, dimension);
		/*
		double errorSum = 0.0;
		double squaredError = 0.0;
		for(int i=0; i<100; i++) {
			double error = testMersenne(numberOfSamples, dimension, random.nextInt());
			errorSum += error;
			squaredError += error*error;
			System.out.println("" + (errorSum/(i+1)) + "\t" + Math.sqrt(squaredError/(i)));
		}
		 */

	}

	static double testHalton1(int numberOfSamples, int dimension) {
		final double piAnalytic = areas[dimension];

		final long timeStart = System.currentTimeMillis();
		final double piHalton = Math.pow(2,dimension)*IntStream.range(0, numberOfSamples).map(
				i -> {
					double radiusSquared = 0.0;
					for(int j=0; j<dimension; j++) {
						final double x = 2.0 * (0.5 - HaltonSequence.getHaltonNumberForGivenBase(i, base[j]));
						radiusSquared += x*x;
					}
					return (radiusSquared < 1) ? 1 : 0;
				}).sum() / numberOfSamples;
		final long timeEnd = System.currentTimeMillis();

		final double time = (double)(timeEnd-timeStart)/1000;
		System.out.println("Sequential using Stream.....: " + (piHalton-piAnalytic) + "\t" + time);
		return time;
	}

	static double testHalton2(int numberOfSamples, int dimension) {
		final double piAnalytic = areas[dimension];

		final long timeStart = System.currentTimeMillis();

		System.setProperty("java.util.concurrent.ForkJoinPool.common.parallelism", "64");
		final double piHalton = Math.pow(2,dimension)*IntStream.range(0, numberOfSamples).parallel().map(
				i -> {
					double radiusSquared = 0.0;
					for(int j=0; j<dimension; j++) {
						final double x = 2.0 * (0.5 - HaltonSequence.getHaltonNumberForGivenBase(i, base[j]));
						radiusSquared += x*x;
					}
					return (radiusSquared < 1) ? 1 : 0;
				}).sum() / numberOfSamples;
		final long timeEnd = System.currentTimeMillis();

		final double time = (double)(timeEnd-timeStart)/1000;
		System.out.println("Parallel using Stream.......: " + (piHalton-piAnalytic) + "\t" + time);
		return time;
	}


	private static double testHalton3(int numberOfSamples, int dimension) throws InterruptedException, ExecutionException {
		final double piAnalytic = areas[dimension];

		final long timeStart = System.currentTimeMillis();

		final int numberOfTask = 128;
		final int numberOfSamplesPerTask = numberOfSamples / numberOfTask;
		final ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

		final List<Future<Double>> results = new ArrayList<>();
		for(int taskIndex = 0; taskIndex<numberOfTask; taskIndex++) {
			final int startIndex = taskIndex*numberOfSamplesPerTask;
			final Future<Double> result = executor.submit( () -> getApproximationOfPiHalton(startIndex, numberOfSamplesPerTask, dimension));
			results.add(result);
		}

		double piHalton = 0.0;
		for(int taskIndex = 0; taskIndex<numberOfTask; taskIndex++) {
			piHalton += results.get(taskIndex).get();
		}
		piHalton /= numberOfTask;

		executor.shutdown();
		final long timeEnd = System.currentTimeMillis();

		final double time = (double)(timeEnd-timeStart)/1000;
		System.out.println("Parallel using Executor.....: " + (piHalton-piAnalytic) + "\t" + time);
		return time;
	}

	private static double testMersenne(int numberOfSamples, int dimension, int seed) throws InterruptedException, ExecutionException {
		final double piAnalytic = areas[dimension];

		final long timeStart = System.currentTimeMillis();
		final double piHalton = getApproximationOfPiMersenne(numberOfSamples, dimension, seed);
		final long timeEnd = System.currentTimeMillis();

		final double time = (double)(timeEnd-timeStart)/1000;
		//		System.out.println("Sequential Mersenne.........: " + (piHalton-piAnalytic) + "\t" + time);
		return piHalton-piAnalytic;
	}

	static double getApproximationOfPiHalton(int startIndex, int numberOfSamples, int dimension) {
		int numberOfPointsInUnitCircle = 0;

		for(int i=startIndex; i<startIndex+numberOfSamples; i++) {
			double radiusSquared = 0.0;
			for(int j=0; j<dimension; j++) {
				final double x = 2.0 * (0.5 - HaltonSequence.getHaltonNumberForGivenBase(i, base[j]));
				radiusSquared += x*x;
			}
			if(radiusSquared < 1) {
				numberOfPointsInUnitCircle++;
			}
		}

		return Math.pow(2,dimension)*numberOfPointsInUnitCircle/numberOfSamples;
	}

	static double getApproximationOfPiMersenne(int numberOfSamples, int dimension, int seed) {
		int numberOfPointsInUnitCircle = 0;

		final RandomNumberGenerator1D mersenne = new MersenneTwister(seed);

		for(int i=0; i<numberOfSamples; i++) {
			double radiusSquared = 0.0;
			for(int j=0; j<dimension; j++) {
				final double x = 2.0 * (0.5 - mersenne.getAsDouble());
				radiusSquared += x*x;
			}
			if(radiusSquared < 1) {
				numberOfPointsInUnitCircle++;
			}
		}

		return Math.pow(2,dimension)*numberOfPointsInUnitCircle/numberOfSamples;
	}
}
