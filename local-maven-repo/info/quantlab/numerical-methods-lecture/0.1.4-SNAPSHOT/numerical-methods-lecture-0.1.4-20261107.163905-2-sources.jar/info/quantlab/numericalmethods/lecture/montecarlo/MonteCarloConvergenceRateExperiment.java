package info.quantlab.numericalmethods.lecture.montecarlo;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import net.finmath.plots.Plots;

public class MonteCarloConvergenceRateExperiment {

	public static void main(String[] args) {

		final Random random = new Random(3141);

		final List<Double> x = new ArrayList<>();
		final List<Double> y = new ArrayList<>();

		final long numberOfSamples = 100000000L;
		double sum = 0.0;
		for(long i = 0; i<numberOfSamples; i++) {
			sum += (random.nextDouble()-0.5);
			final double avg = sum / (i+1);

			final double conv = avg*Math.sqrt(i+1);
			if(i%10000 == 0) {
				System.out.println(avg + "\t" + conv);
				x.add((double)(i+1));
				y.add(conv);
			}
		}

		Plots.createScatter(x, y, 0, x.size(), 3).show();
	}
}
