package info.quantlab.test;

import java.util.Arrays;
import java.util.Random;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;

import org.apache.commons.math3.random.MersenneTwister;

import net.finmath.functions.NormalDistribution;
import net.finmath.randomnumbers.SobolSequence;
import net.finmath.randomnumbers.SobolSequence1D;

public class SobolTest {

	public static void main(String[] args) {

		final SobolSequence1D sobol = new SobolSequence1D();

		DoubleStream.generate(sobol).limit(16).map(x -> 1.0/x).forEach(System.out::println);

		final SobolSequence sobol2 = new SobolSequence(3);
		IntStream.range(0, 5).forEach(i -> {
			System.out.println(Arrays.toString(sobol2.getNext()));
		});


		System.out.println("_________");

		final double normal = NormalDistribution.inverseCumulativeDistribution(1E-11);

		final double x = NormalDistribution.cumulativeDistribution(normal);
		final org.apache.commons.math3.distribution.NormalDistribution normalDistribution  = new org.apache.commons.math3.distribution.NormalDistribution();

		final double normal2 = normalDistribution.inverseCumulativeProbability(1.0);
		System.out.println(normal);
		System.out.println(normal2);
		System.out.println(x);

		final MersenneTwister mersenne = new MersenneTwister(3141);
		final Random random = new Random(3141);
		final double firstValue = random.nextDouble();
		long lastRepeat = 0;
		for(long i = 0; i < Long.MAX_VALUE; i++) {
			final double value = random.nextDouble();
			if(value == firstValue)	{
				final long repeat = i-lastRepeat;
				lastRepeat = i;
				System.out.println("Repeated after." + repeat);
			}
			if(value == 0.0) {
				System.out.println("Zero at......." + i);
			}
		}

	}

}
