package info.quantlab.test;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleUnaryOperator;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;

import org.apache.commons.math3.random.SobolSequenceGenerator;

import info.quantlab.numericalmethods.lecture.randomnumbers.VanDerCorputSequence;
import net.finmath.plots.Plot2D;
import net.finmath.plots.Plotable2D;
import net.finmath.plots.PlotableFunction2D;
import net.finmath.randomnumbers.MersenneTwister;

public class MonteCarloIntegrationQuasiExperiment {

	private static DecimalFormat formatter = new DecimalFormat(" 0.000E00;-0.000E00");

	public static void main(String[] args) throws InterruptedException {

		DoubleUnaryOperator function = x -> x*x*x;

		double integralAnalytic = 1.0/4.0;

		function = x -> -Math.sin(x);
		integralAnalytic = Math.cos(1)-Math.cos(0);

		final int numberOfSamplePoints = 100000;

		final MersenneTwister mersenne = new MersenneTwister(3141);

		System.out.println("Integration Errors:");
		System.out.println("n" + "\t" + "mersenne" + "\t" + "equidistant" + "\t" + "v.-d.-corput");

		/*
		 * Simultaneously "integrate" using Mersenne, on equidistributed and using Van-Der-Corput
		 */

		double sumMersenneTwister = 0.0;
		double sumEquidistributed = 0.0;
		double sumVanDerCorput = 0.0;
		double sumSobol = 0.0;

		final List<Double> partialIntegral1 = new ArrayList<>();
		final List<Double> partialIntegral2 = new ArrayList<>();
		final List<Double> partialIntegral3 = new ArrayList<>();
		final List<Double> partialIntegral4 = new ArrayList<>();
		final List<Double> partialIntegral5 = new ArrayList<>();

		final Plot2D plot = new Plot2D(List.of(new PlotableFunction2D(0, 0, 2, x -> 0.0)));
		plot.show();

		final int currentNumberOfSamplePoints2 = 128;
		final DoubleStream stream1 = IntStream.range(0,currentNumberOfSamplePoints2).mapToDouble(j -> ((j)+0.5)/currentNumberOfSamplePoints2).map(function);
		final DoubleStream stream2 = DoubleStream.generate(new VanDerCorputSequence(2)).limit(currentNumberOfSamplePoints2).sorted().map(function);
		stream1.forEach(x -> System.out.println(x));
		stream2.forEach(x -> System.out.println(x));

		final SobolSequenceGenerator generator = new SobolSequenceGenerator(1);

		double minErrorMersenneTwister = Double.MAX_VALUE;
		double minErrorSobol = Double.MAX_VALUE;
		double minErrorVanDerCorput2 = Double.MAX_VALUE;

		int k = 4;
		for(int i=0; i<numberOfSamplePoints; i++) {
			sumMersenneTwister += function.applyAsDouble(mersenne.nextDouble());
			sumEquidistributed += function.applyAsDouble((double)i/numberOfSamplePoints);
			sumVanDerCorput += function.applyAsDouble(VanDerCorputSequence.getVanDerCorputNumber(i, 2));
			sumSobol += function.applyAsDouble(generator.nextVector()[0]);

			final int currentNumberOfSamplePoints = (i+1);

			final double integralMersenneTwister = sumMersenneTwister / currentNumberOfSamplePoints;
			final double errorMersenneTwister = integralMersenneTwister-integralAnalytic;
			minErrorMersenneTwister = Math.min(minErrorMersenneTwister, Math.abs(errorMersenneTwister));
			partialIntegral1.add(minErrorMersenneTwister);

			final double integralSobol = sumSobol / currentNumberOfSamplePoints;
			final double errorSobol = integralSobol-integralAnalytic;
			minErrorSobol = Math.min(minErrorSobol, Math.abs(errorSobol));
			partialIntegral5.add(minErrorSobol);

			sumEquidistributed = IntStream.range(0,currentNumberOfSamplePoints).mapToDouble(j -> ((j)+0.5)/currentNumberOfSamplePoints).map(function).sum();
			final double integralEquidistributed = sumEquidistributed / currentNumberOfSamplePoints;
			final double errorEquidistributed = integralEquidistributed-integralAnalytic;
			partialIntegral2.add(errorEquidistributed);

			double integralVanDerCorput = sumVanDerCorput / (currentNumberOfSamplePoints);
			final double errorVanDerCorput1 = integralVanDerCorput-integralAnalytic;
			partialIntegral3.add(errorVanDerCorput1);

			integralVanDerCorput *= currentNumberOfSamplePoints;
			integralVanDerCorput /= (currentNumberOfSamplePoints+1);
			integralVanDerCorput += function.applyAsDouble(1)/2/(currentNumberOfSamplePoints+1);
			integralVanDerCorput += function.applyAsDouble(0)/2/(currentNumberOfSamplePoints+1);
			//			integralVanDerCorput += function.applyAsDouble(1-1.0/(4*(currentNumberOfSamplePoints)))/2/(currentNumberOfSamplePoints);
			//			integralVanDerCorput += function.applyAsDouble(0+1.0/(4*(currentNumberOfSamplePoints)))/2/(currentNumberOfSamplePoints);
			final double errorVanDerCorput2 = integralVanDerCorput-integralAnalytic;
			minErrorVanDerCorput2 = Math.min(minErrorVanDerCorput2, Math.abs(errorVanDerCorput2));
			partialIntegral4.add(minErrorVanDerCorput2);

			final int start = 0;
			final int end = currentNumberOfSamplePoints-1;

			final DoubleUnaryOperator plot1 = x -> Math.log10(1E-14+Math.abs(partialIntegral1.get(Math.min((int)x,partialIntegral1.size()-1))));
			final DoubleUnaryOperator plot2 = x -> Math.log10(1E-14+Math.abs(partialIntegral2.get(Math.min((int)x,partialIntegral2.size()-1))));
			final DoubleUnaryOperator plot3 = x -> Math.log10(1E-14+Math.abs(partialIntegral3.get(Math.min((int)x,partialIntegral3.size()-1))));
			final DoubleUnaryOperator plot4 = x -> Math.log10(1E-14+Math.abs(partialIntegral4.get(Math.min((int)x,partialIntegral4.size()-1))));
			final DoubleUnaryOperator plot5 = x -> Math.log10(1E-14+Math.abs(partialIntegral5.get(Math.min((int)x,partialIntegral5.size()-1))));

			// Print every 100 points the intermediate result
			if((currentNumberOfSamplePoints+1) % k == 0) {
				k=k*2;
				final List<Plotable2D> plotables =
						List.of(
								//							new PlotableFunction2D(start, end, end-start+1, x -> Math.log10(1.0/Math.sqrt(x+1))),
								new PlotableFunction2D(start, end, end-start+1, plot3),
								new PlotableFunction2D(start, end, end-start+1, plot4),
								new PlotableFunction2D(start, end, end-start+1, plot5),
								//							new PlotableFunction2D(start, end, end-start+1, plot1),
								//							new PlotableFunction2D(start, end, end-start+1, plot2),
								new PlotableFunction2D(start, end, end-start+1, x -> Math.log10(Math.log(x+2)/(x+2))),
								new PlotableFunction2D(start, end, end-start+1, x -> Math.log10(1.0/(x+2))),
								new PlotableFunction2D(start, end, end-start+1, x -> Math.log10(1.0/(x+2)/(x+2)))
								);
				plot.update(plotables);
				Thread.sleep(100);

				System.out.print((i+1) + "\t" +
						formatter.format(errorMersenneTwister) + "\t" +
						formatter.format(errorEquidistributed) + "\t" +
						formatter.format(errorSobol) + "\t" +
						formatter.format(errorVanDerCorput2) + "\t" +
						formatter.format(errorVanDerCorput1) + "\n");

			}
		}

		/*
		 * Calculate the final result.
		 */
		final double integralMersenneTwister = sumMersenneTwister / numberOfSamplePoints;
		final double errorMersenneTwister = integralMersenneTwister-integralAnalytic;

		final double integralEquidistributed = sumEquidistributed / numberOfSamplePoints;
		final double errorEquidistributed = integralEquidistributed-integralAnalytic;

		final double integralVanDerCorput = sumVanDerCorput / numberOfSamplePoints;
		final double errorVanDerCorput = integralVanDerCorput-integralAnalytic;

		System.out.println();

		System.out.println("Pseudo RNG....: " + integralMersenneTwister + "\t error: " + errorMersenneTwister);
		System.out.println("Equidistri....: " + integralEquidistributed + "\t error: " + errorEquidistributed);
		System.out.println("v.d.Corput....: " + integralVanDerCorput + "\t error: " + errorVanDerCorput);

	}

}
