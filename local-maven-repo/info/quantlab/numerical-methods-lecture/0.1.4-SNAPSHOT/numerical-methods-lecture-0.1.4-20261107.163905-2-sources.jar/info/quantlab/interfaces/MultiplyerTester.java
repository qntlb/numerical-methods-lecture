package info.quantlab.interfaces;

public class MultiplyerTester {

	void test(Multiplyer multiplyer) {

		final double value = multiplyer.multiply(1.0, 2.0);

		final boolean success = (value == 2.0);

		System.out.println(multiplyer.getClass().getSimpleName() + "\t" + success);
	}
}
