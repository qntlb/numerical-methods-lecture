/**
 * Interface definitions for example implementations.
 *
 * @author Christian Fries
 */
package info.quantlab.interfaces;
