package info.quantlab.test;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;
import java.util.function.DoubleUnaryOperator;

import net.finmath.exception.CalculationException;
import net.finmath.functions.AnalyticFormulas;
import net.finmath.montecarlo.BrownianMotion;
import net.finmath.montecarlo.BrownianMotionFromMersenneRandomNumbers;
import net.finmath.montecarlo.assetderivativevaluation.MonteCarloAssetModel;
import net.finmath.montecarlo.assetderivativevaluation.models.BlackScholesModel;
import net.finmath.montecarlo.process.EulerSchemeFromProcessModel;
import net.finmath.montecarlo.process.MonteCarloProcess;
import net.finmath.plots.Plot2D;
import net.finmath.plots.PlotableFunction2D;
import net.finmath.stochastic.RandomOperator;
import net.finmath.stochastic.Scalar;
import net.finmath.time.TimeDiscretizationFromArray;

public class MonteCarloBlackScholesDeltaExperiments2 {

	private static double initialValue = 100.0;
	private static int seed = 3216;

	public static void main(String[] args) throws CalculationException {

		final double riskFreeRate = 0.05;
		final double volatility = 0.30;

		final double maturity = 5.0;
		final double strike = 125.0;

		final double timeHorizon = maturity;
		final double dt = 5.0;

		final int numberOfPaths = 10000;

		final MonteCarloAssetModel model = getModel(riskFreeRate, volatility, timeHorizon, dt, numberOfPaths);
		final double valueAnalytic = AnalyticFormulas.blackScholesOptionValue(initialValue, riskFreeRate, volatility, maturity, strike);

		final RandomOperator payoffFunctionZero = underlying -> new Scalar(0.0);
		final RandomOperator payoffFunctionOne = underlying -> new Scalar(1.0);
		final RandomOperator payoffFunctionNaN = underlying -> new Scalar(Double.NaN);

		final RandomOperator payoffFunctionBond = underlying -> new Scalar(100.0);
		final RandomOperator payoffFunctionForward = underlying -> underlying;
		final RandomOperator payoffFunctionOption = underlying -> underlying.sub(strike).floor(0.0);
		final RandomOperator payoffFunctionDigital = underlying -> underlying.sub(strike).choose(new Scalar(1.0), new Scalar(0.0));

		final double valueMonteCarlo = getValueMonteCarlo(model, maturity, payoffFunctionOption);

		printResult("Valuation...:", valueMonteCarlo, valueAnalytic);

		System.out.println("\nBond:");
		final double valueDeltaBondAnalytic = 0.0;
		checkApproximationMethodsForPayoff(initialValue, riskFreeRate, volatility, maturity, strike, model,
				payoffFunctionBond, payoffFunctionZero, valueDeltaBondAnalytic);

		System.out.println("\nForward:");
		final double valueDeltaForwardAnalytic = 1.0;
		checkApproximationMethodsForPayoff(initialValue, riskFreeRate, volatility, maturity, strike, model,
				payoffFunctionForward, payoffFunctionOne, valueDeltaForwardAnalytic);

		System.out.println("\nEuropean Option:");
		final double valueDeltaAnalytic = AnalyticFormulas.blackScholesOptionDelta(initialValue, riskFreeRate, volatility, maturity, strike);
		checkApproximationMethodsForPayoff(initialValue, riskFreeRate, volatility, maturity, strike, model,
				payoffFunctionOption, payoffFunctionDigital, valueDeltaAnalytic);

		System.out.println("\nDigital Option:");
		final double valueDeltaDigitalAnalytic = AnalyticFormulas.blackScholesDigitalOptionDelta(initialValue, riskFreeRate, volatility, maturity, strike);
		checkApproximationMethodsForPayoff(initialValue, riskFreeRate, volatility, maturity, strike, model,
				payoffFunctionDigital, payoffFunctionNaN, valueDeltaDigitalAnalytic);


		getPlotOfFiniteDifferenceAprroxByShift(2, 12, model, maturity, payoffFunctionOption)
		.setTitle("Finite Difference Approximation of Delta of European Option")
		.setXAxisLabel("scale (shift = S(0)*10^{-scale}")
		.setYAxisLabel("value")
		.setYAxisNumberFormat(new DecimalFormat("0.#####"));
		//		.show();

		getPlotOfFiniteDifferenceAprroxByShift(2, 8, model, maturity, payoffFunctionDigital)
		.setTitle("Finite Difference Approximation of Delta of Digital Option")
		.setXAxisLabel("scale (shift = S(0)*10^{-scale}")
		.setYAxisLabel("value")
		.setYAxisNumberFormat(new DecimalFormat("0.#####"));
		//		.show();

	}

	private static void checkApproximationMethodsForPayoff(
			double initialValue, double riskFreeRate, double volatility, double maturity, double strike,
			MonteCarloAssetModel model, RandomOperator payoffFunction, RandomOperator payoffDerivativeFuntion, double valueAnalytic) throws CalculationException {

		final double valueDeltaFiniteDifference1 = getDeltaFiniteDifference(model, maturity, payoffFunction, 1E-1);
		printResult("Finite Diff (h=1e-1).:", valueDeltaFiniteDifference1, valueAnalytic);
		final double valueDeltaFiniteDifference3 = getDeltaFiniteDifference(model, maturity, payoffFunction, 1E-3);
		printResult("Finite Diff (h=1e-3):", valueDeltaFiniteDifference3, valueAnalytic);

		final double valueDeltaPathwiseMethod = getDeltaPathwiseMethod(model, maturity, payoffDerivativeFuntion);
		printResult("Pathwise Method:", valueDeltaPathwiseMethod, valueAnalytic);

		final double valueDeltaLikelihoodRatio = getDeltaLikelihoodMethod(model, maturity, payoffFunction);
		printResult("Likelihood Ratio:", valueDeltaLikelihoodRatio, valueAnalytic);
	}


	private static double getDeltaLikelihoodMethod(MonteCarloAssetModel model, double maturity, RandomOperator payoffFuntion) throws CalculationException {

		final BlackScholesModel blackScholesModel = (BlackScholesModel)(model.getModel());

		final var riskFreeRate = blackScholesModel.getRiskFreeRate();
		final var sigma = blackScholesModel.getVolatility();
		final var T = maturity;
		final var ST = model.getAssetValue(maturity, 0);

		final var x = ST.div(initialValue).log().sub(riskFreeRate.mult(T)).add(sigma.squared().mult(maturity).mult(0.5)).div(sigma).div(Math.sqrt(T));
		final var lr = x.div(initialValue).div(sigma).div(Math.sqrt(T));

		final RandomOperator payoffFunctionWeighted = underlying -> payoffFuntion.apply(underlying).mult(lr);
		return getValueMonteCarlo(model, maturity, payoffFunctionWeighted);
	}

	private static double getDeltaPathwiseMethod(MonteCarloAssetModel model, double maturity, RandomOperator payoffDerivativeFuntion) throws CalculationException {
		final RandomOperator payoffModified = underlying -> payoffDerivativeFuntion.apply(underlying).mult(underlying.div(initialValue));
		return getValueMonteCarlo(model, maturity, payoffModified);
	}

	private static Plot2D getPlotOfFiniteDifferenceAprroxByShift(double xmin, double xmax, MonteCarloAssetModel model, double maturity, RandomOperator payoffFunction) {

		final DoubleUnaryOperator finiteDifferenceApproxByScale = scale -> getDeltaFiniteDifference(model, maturity, payoffFunction, initialValue*Math.pow(10, -scale));
		return new Plot2D(List.of(new PlotableFunction2D(xmin, xmax, 400, finiteDifferenceApproxByScale)));
	}

	private static double getDeltaFiniteDifference(MonteCarloAssetModel model, double maturity, RandomOperator payoffFunction, double shift) {
		try {
			final MonteCarloAssetModel modelUpShift = model.getCloneWithModifiedData(Map.of("initialValue", initialValue+shift));
			final double valueUpShift = getValueMonteCarlo(modelUpShift, maturity, payoffFunction);

			final MonteCarloAssetModel modelDnShift = model.getCloneWithModifiedData(Map.of("initialValue", initialValue-shift));
			final double valueDnShift = getValueMonteCarlo(modelDnShift, maturity, payoffFunction);

			return (valueUpShift-valueDnShift)/(2*shift);
		} catch (final CalculationException e) {
			e.printStackTrace();
			return Double.NaN;
		}
	}

	private static void printResult(String name, double valueMonteCarlo, double valueAnalytic) {
		System.out.format("%24s\t%+10.6f\t%+10.6f\t%+9.5e\n", name, valueMonteCarlo, valueAnalytic, valueMonteCarlo-valueAnalytic);
	}

	private static double getValueMonteCarlo(MonteCarloAssetModel model, double maturity, RandomOperator payoffFunction) throws CalculationException {

		final var underlying = model.getAssetValue(maturity, 0);
		final var payoff = payoffFunction.apply(underlying);
		final var value = payoff.div(model.getNumeraire(maturity).mult(model.getNumeraire(0.0)));

		return value.average().doubleValue();
	}

	private static MonteCarloAssetModel getModel(double riskFreeRate, double volatility, double timeHorizon, double dt, int numberOfPaths) {

		final BlackScholesModel blackScholesModel = new BlackScholesModel(initialValue, riskFreeRate, volatility);
		final BrownianMotion bm = new BrownianMotionFromMersenneRandomNumbers(new TimeDiscretizationFromArray(0.0, (int)Math.round(timeHorizon/dt), dt),
				1, numberOfPaths, seed);
		final MonteCarloProcess process = new EulerSchemeFromProcessModel(blackScholesModel, bm);

		return new MonteCarloAssetModel(process);
	}

}
