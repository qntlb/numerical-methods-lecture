package info.quantlab.numericalmethods.lecture.montecarlo.integration2d.experiment;

import java.util.function.BiFunction;

/**
 * Monte-Carlo integration of
 * integral cos(x) * cos(y) dx dy, x = -pi/2 to pi/2, y = -pi/2 to pi/2
 */
public class MonteCarloIntegration2DExperiment {

	private static final int numberOfSamples = 1000000;

	public static void main(String[] args) {

		System.out.println("Monte-Carlo integration of\n"
				+ "  ∫ cos(x)•cos(y) dx dy,   x from -𝜋/2 to 𝜋/2, y from -𝜋/2 to 𝜋/2"
				+ "\n"
				+ "_".repeat(79));

		final double xlower = -Math.PI/2;
		final double xupper = +Math.PI/2;
		final double ylower = -Math.PI/2;
		final double yupper = +Math.PI/2;

		final BiFunction<Double,Double,Double> integrand = (x,y) -> Math.cos(x)*Math.cos(y);

		// General code to integrate integrand on the given domain
		final double integral = integrate(integrand, xlower, xupper, ylower, yupper);

		final double integralAnalytic = (Math.sin(xupper)-Math.sin(xlower)) * (Math.sin(yupper)-Math.sin(ylower));
		final double error = integral - integralAnalytic;

		System.out.println("Monte-Carlo Integral....: " + integral);
		System.out.println("Analytic Integral.......: " + integralAnalytic);
		System.out.println("Deviation...............: " + String.format("%5.2e", error));
		System.out.println("sqrt(1/N)...............: " + String.format("%5.2e", Math.sqrt(1.0/numberOfSamples)));
		System.out.println("Number of Samples.......: " + String.format("%5.2e", (double)numberOfSamples));

	}

	private static double integrate(BiFunction<Double,Double,Double> integrand,
			double xlower, double xupper, double ylower, double yupper) {

		double sum = 0.0;
		for(int i=0; i<numberOfSamples; i++) {

			final double x = Math.random() * (xupper-xlower) + xlower;
			final double y = Math.random() * (yupper-ylower) + ylower;

			sum += integrand.apply(x, y);
		}
		return sum/numberOfSamples * (xupper-xlower) * (yupper-ylower);
	}

}
