package info.quantlab.test;

import java.util.function.DoubleUnaryOperator;

import net.finmath.functions.NormalDistribution;

public class NormalICDFExperiments {

	public static void main(String[] args) {

		final double pSmall = Double.MIN_VALUE;
		testNormalInverseDistribution(
				"Wichura approximation (finmath)",
				NormalDistribution::inverseCumulativeNormalDistributionWichura,
				pSmall);

		final double pSmall2 = 1.0/Math.pow(2, 53);
		testNormalInverseDistribution(
				"Wichura approximation (finmath)",
				NormalDistribution::inverseCumulativeNormalDistributionWichura,
				pSmall2);

		final double pLarge = 1.0 - 1E-16;
		testNormalInverseDistribution(
				"Wichura approximation (finmath)",
				NormalDistribution::inverseCumulativeNormalDistributionWichura,
				pLarge);

		testNormalInverseDistribution(
				"Wichura approximation (finmath)",
				NormalDistribution::inverseCumulativeNormalDistributionWichura,
				1- pLarge);

		final org.apache.commons.math3.distribution.NormalDistribution normal = new org.apache.commons.math3.distribution.NormalDistribution();

		testNormalInverseDistribution(
				"Apache commons-math (3.6.2)",
				normal::inverseCumulativeProbability,
				pSmall);

		testNormalInverseDistribution(
				"Apache commons-math (3.6.2)",
				normal::inverseCumulativeProbability,
				pSmall2);

		testNormalInverseDistribution(
				"Apache commons-math (3.6.2)",
				normal::inverseCumulativeProbability,
				pLarge);

		testNormalInverseDistribution(
				"Apache commons-math (3.6.2)",
				normal::inverseCumulativeProbability,
				1-pLarge);
	}

	static void testNormalInverseDistribution(String name, DoubleUnaryOperator icdf, double p) {

		System.out.println("_".repeat(80));
		System.out.println("Testing " + name);

		System.out.println("p      = " + p);

		final double x = icdf.applyAsDouble(p);

		System.out.println("x(p)   = " + x);

		final double pFromX = NormalDistribution.cumulativeDistribution(x);

		System.out.println("p(x)   = " + pFromX);

		final double expOfX = Math.exp(x);
		System.out.println("exp(x) = " + expOfX);
	}
}
