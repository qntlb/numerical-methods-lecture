package info.quantlab.test;

import java.text.DecimalFormat;
import java.util.function.DoubleUnaryOperator;

import net.finmath.plots.Plot2D;

public class FiniteDifferenceExperiments1 {

	public static void main(String[] args) {

		final double x = 0.0;
		final double shift = 0.01;

		printForwardFiniteDifferenceApproximationOfExp(x, 0.01);
		printForwardFiniteDifferenceApproximationOfExp(x, 0.0001);
		printForwardFiniteDifferenceApproximationOfExp(x, 1E-16);
		printForwardFiniteDifferenceApproximationOfExp(x, 1E-15);
		printForwardFiniteDifferenceApproximationOfExp(x, 1E-12);
		printForwardFiniteDifferenceApproximationOfExp(x, Math.pow(2, -52));
		printForwardFiniteDifferenceApproximationOfExp(x, 1.5*Math.pow(2, -52));
		printForwardFiniteDifferenceApproximationOfExp(x, shift);

		plotErrorOfForwardFiniteDifferenceApproximationOfExp(x);
	}

	private static void printForwardFiniteDifferenceApproximationOfExp(double x, double shift) {

		final double finiteDifferenceApproximation = (Math.exp(x+shift)-Math.exp(x))/shift;

		System.out.println("h = " + shift + "  \t  finiteDifferenceApprox = " + finiteDifferenceApproximation);
	}

	private static void plotErrorOfForwardFiniteDifferenceApproximationOfExp(double x) {

		final DoubleUnaryOperator finiteDifferceApproximationError = scale ->
		{
			final double shift = Math.pow(10, -scale);
			final double finiteDifferenceApproximation = (Math.exp(x+shift)-Math.exp(x))/shift;
			final double derivativeAnalytic = Math.exp(x);
			final double error = finiteDifferenceApproximation - derivativeAnalytic;
			return error;
		};

		final Plot2D plot = new Plot2D(14, 16.5, 200, finiteDifferceApproximationError);
		plot.setTitle("(One Sided Finite Difference) Derivative of exp(x) at x = " + x)
		.setXAxisLabel("scale (h = 10^{-scale})")
		.setYAxisLabel("error")
		.setYAxisNumberFormat(new DecimalFormat("0E00"));

		plot.show();

	}
}
