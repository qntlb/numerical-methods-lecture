package info.quantlab.interfaces.differential;

public interface DifferentialOperator {


}
