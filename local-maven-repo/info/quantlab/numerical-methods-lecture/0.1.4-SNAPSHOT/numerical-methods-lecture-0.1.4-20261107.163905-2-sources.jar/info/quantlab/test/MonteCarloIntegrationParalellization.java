package info.quantlab.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.IntStream;

import net.finmath.randomnumbers.HaltonSequence;
import net.finmath.randomnumbers.MersenneTwister;

/**
 * Some experiments on the parallelization of the Monte-Carlo approximation of pi.
 *
 * @author Christian Fries
 */
public class MonteCarloIntegrationParalellization {

	private static double piAnalytic = Math.PI;

	public static void main(String[] args) throws InterruptedException, ExecutionException {

		final int numberOfSamples = 200000000;  // 2*10^8

		testHaltonWithStreamSeq(numberOfSamples);
		testHaltonWithExecutor(numberOfSamples);
		testHaltonWithStreamPar(numberOfSamples);

		testMersenneStreamSeq(numberOfSamples);
		testMersenneWithExecutor(numberOfSamples);
	}



	static double testHaltonWithStreamSeq(int numberOfSamples) {

		final long timeStart = System.currentTimeMillis();
		final double piHalton = 4.0*IntStream.range(0, numberOfSamples).map(
				i -> {
					final double x = 2.0 * (0.5 - HaltonSequence.getHaltonNumberForGivenBase(i, 2));
					final double y = 2.0 * (0.5 - HaltonSequence.getHaltonNumberForGivenBase(i, 3));
					return (x*x + y*y < 1) ? 1 : 0;
				}).sum() / numberOfSamples;
		final long timeEnd = System.currentTimeMillis();

		final double time = (double)(timeEnd-timeStart)/1000;
		System.out.println("Halton, sequential using Stream.....: " + (piHalton-piAnalytic) + "\t" + time);
		return time;
	}



	static double testHaltonWithStreamPar(int numberOfSamples) {

		final long timeStart = System.currentTimeMillis();
		final double piHalton = 4.0*IntStream.range(0, numberOfSamples).parallel().map(
				i -> {
					final double x = 2.0 * (0.5 - HaltonSequence.getHaltonNumberForGivenBase(i, 2));
					final double y = 2.0 * (0.5 - HaltonSequence.getHaltonNumberForGivenBase(i, 3));
					return (x*x + y*y < 1) ? 1 : 0;
				}).sum() / numberOfSamples;
		final long timeEnd = System.currentTimeMillis();

		final double time = (double)(timeEnd-timeStart)/1000;
		System.out.println("Halton, parallel using Stream.......: " + (piHalton-piAnalytic) + "\t" + time);
		return time;
	}



	private static double testHaltonWithExecutor(int numberOfSamples) throws InterruptedException, ExecutionException {
		final double piAnalytic = Math.PI;

		final long timeStart = System.currentTimeMillis();

		final int numberOfTask = 128;
		final int numberOfSamplesPerTask = numberOfSamples / numberOfTask;
		final ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

		final List<Future<Double>> results = new ArrayList<>();
		for(int taskIndex = 0; taskIndex<numberOfTask; taskIndex++) {
			final int startIndex = taskIndex*numberOfSamplesPerTask;
			final Future<Double> result = executor.submit(
					() -> getApproximationOfPiHalton(startIndex, numberOfSamplesPerTask));
			results.add(result);
		}

		double piHalton = 0.0;
		for(int taskIndex = 0; taskIndex<numberOfTask; taskIndex++) {
			piHalton += results.get(taskIndex).get();
		}
		piHalton /= numberOfTask;

		executor.shutdown();
		final long timeEnd = System.currentTimeMillis();

		final double time = (double)(timeEnd-timeStart)/1000;
		System.out.println("Halton, parallel using Executor.....: " + (piHalton-piAnalytic) + "\t" + time);
		return time;
	}




	static double testMersenneStreamSeq(int numberOfSamples) {

		final long timeStart = System.currentTimeMillis();
		final org.apache.commons.math3.random.MersenneTwister mersenne = new org.apache.commons.math3.random.MersenneTwister(3141);
		final double piMersenne = 4.0*IntStream.range(0, numberOfSamples).mapToDouble(
				i -> {
					final double x = 2.0 * (0.5 - mersenne.nextDouble());
					final double y = 2.0 * (0.5 - mersenne.nextDouble());
					return (x*x + y*y < 1) ? 1 : 0;
				}).sum() / numberOfSamples;
		final long timeEnd = System.currentTimeMillis();

		final double time = (double)(timeEnd-timeStart)/1000;
		System.out.println("Mersenne, sequential using Stream...: " + (piMersenne-piAnalytic) + "\t" + time);
		return time;
	}


	static double testMersenneWithExecutor(int numberOfSamples) throws InterruptedException, ExecutionException {

		final long timeStart = System.currentTimeMillis();

		final Random random = new Random(3141);

		final int numberOfTask = 128;
		final int numberOfSamplesPerTask = numberOfSamples / numberOfTask;
		final ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

		final List<Future<Double>> results = new ArrayList<>();
		for(int taskIndex = 0; taskIndex<numberOfTask; taskIndex++) {
			final long seed = random.nextLong();
			final Future<Double> result = executor.submit(
					() -> getApproximationOfPiMersenne(seed, numberOfSamplesPerTask));
			results.add(result);
		}

		double piHalton = 0.0;
		for(int taskIndex = 0; taskIndex<numberOfTask; taskIndex++) {
			piHalton += results.get(taskIndex).get();
		}
		piHalton /= numberOfTask;

		executor.shutdown();
		final long timeEnd = System.currentTimeMillis();

		final double time = (double)(timeEnd-timeStart)/1000;
		System.out.println("Mersenne, parallel using Executor...: " + (piHalton-piAnalytic) + "\t" + time);
		return time;
	}


	static double getApproximationOfPiHalton(int startIndex, int numberOfSamples) {

		int numberOfPointsInUnitCircle = 0;
		for(int i=startIndex; i<startIndex+numberOfSamples; i++) {
			final double x = 2.0 * (0.5 - HaltonSequence.getHaltonNumberForGivenBase(i, 2));
			final double y = 2.0 * (0.5 - HaltonSequence.getHaltonNumberForGivenBase(i, 3));
			if(x*x + y*y < 1) {
				numberOfPointsInUnitCircle++;
			}
		}

		return 4.0*numberOfPointsInUnitCircle/numberOfSamples;
	}


	static double getApproximationOfPiMersenne(long seed, int numberOfSamples) {

		final MersenneTwister mersenne = new MersenneTwister(seed);

		int numberOfPointsInUnitCircle = 0;
		for(int i=0; i<numberOfSamples; i++) {
			final double x = 2.0 * (0.5 - mersenne.nextDouble());
			final double y = 2.0 * (0.5 - mersenne.nextDouble());
			if(x*x + y*y < 1) {
				numberOfPointsInUnitCircle++;
			}
		}

		return 4.0*numberOfPointsInUnitCircle/numberOfSamples;
	}
}
