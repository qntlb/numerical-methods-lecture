package info.quantlab.test;

import java.util.ArrayList;
import java.util.List;

import net.finmath.plots.Plot;
import net.finmath.plots.Plots;
import net.finmath.randomnumbers.SobolSequence1D;

public class SobolSequenceTest {

	public static void main(String[] args) throws Exception {

		final SobolSequence1D sobol = new SobolSequence1D();
		sobol.nextDouble();
		final org.apache.commons.math3.distribution.NormalDistribution normal = new org.apache.commons.math3.distribution.NormalDistribution();


		final List<Double> values = new ArrayList<>();

		for(int i=0; i<100; i++) {
			final double sobolNumber = sobol.nextDouble();

			final double normalFromSobolNumber = normal.inverseCumulativeProbability(sobolNumber);
			System.out.println(sobolNumber + "\t\t" + normalFromSobolNumber);

			values.add(sobolNumber);
		}

		final Plot plot = Plots.createHistogram(values, 100, 4.0);
		plot.show();
	}

}
