package info.quantlab.test;

public class StaticMethodTest1 {

	public static void testStatic() { System.out.println("1"); }

	public void test() { testStatic(); }

}
