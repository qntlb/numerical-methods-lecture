package info.quantlab.numericalmethods.lecture.randomnumbers.experiments;

import java.util.ArrayList;
import java.util.List;

import net.finmath.plots.Plot;
import net.finmath.plots.Plots;

public class LCGExperiments {

	public static void main(String[] args) throws Exception {

		final int m = 8192-1;	// prime number 2^13-1
		final int a = 153;
		final int c = 13312;

		int r = 0;

		final List<Double> xValues = new ArrayList<>();
		final List<Double> yValues = new ArrayList<>();

		final int numberOfSamples = 1000000;
		for(int i=0; i<numberOfSamples; i++) {
			r = next(r,a,c,m);
			final double x = (double)r/m;
			r = next(r,a,c,m);
			final double y = (double)r/m;

			xValues.add(x);
			yValues.add(y);

		}
		final Plot plot = Plots.createScatter(
				xValues,
				yValues,
				0.0, 1.0, 1);

		plot.show();
	}

	private static int next(int r, int a, int c, int m) {
		System.out.println((double)r/m);
		return (r * a + c) % m;
	}

}
