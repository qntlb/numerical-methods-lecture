package info.quantlab.interfaces;

public class MyOtherMultiplyer implements Multiplyer {

	@Override
	public double multiply(double a, double b) {
		return 2 * a * b;
	}
}
