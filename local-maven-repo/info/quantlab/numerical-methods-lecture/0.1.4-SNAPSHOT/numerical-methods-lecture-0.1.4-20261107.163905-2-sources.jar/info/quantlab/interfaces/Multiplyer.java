package info.quantlab.interfaces;

public interface Multiplyer {

	double multiply(double a, double b);

}
