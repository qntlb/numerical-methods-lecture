package info.quantlab.test;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.DoubleUnaryOperator;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;

import org.apache.commons.math3.random.SobolSequenceGenerator;

import info.quantlab.numericalmethods.lecture.randomnumbers.VanDerCorputSequence;
import net.finmath.functions.AnalyticFormulas;
import net.finmath.functions.NormalDistribution;
import net.finmath.plots.Named;
import net.finmath.plots.Plot2D;
import net.finmath.plots.Plotable2D;
import net.finmath.plots.PlotableFunction2D;
import net.finmath.randomnumbers.MersenneTwister;

public class MonteCarloQuasiBlackScholes {

	private final double[] goodSet1 = { 3.0, 1.05, 1.0, 0.05, 0.20};
	private final double[] goodSet2 = { 3.0, 1.05, 1.0, 0.05, 0.20};

	private static double optionMaturity = 2.0;
	private static double optionStrike = 0.0*Math.exp(0.05*2.0);

	private static double initialValue = 1.0;
	private static double riskFreeRate = 0.05;
	private static double volatility = 0.20;

	static class Aggregator implements DoubleUnaryOperator {
		double sum = 0.0;
		double error = 0.0;
		int index = 0;

		@Override
		public double applyAsDouble(double value) {
			index++;
			final double newSum = sum + (value-error);
			error = (newSum - sum) - value;
			sum = newSum;
			return sum / index;
		}
	}

	public static void main(String[] args) throws IOException {

		final Plot2D plot = new Plot2D(List.of(new PlotableFunction2D(0, 0, 2, x -> 0.0)));
		plot.setIsLegendVisible(true);
		plot.show();

		for(double optionStrike2 = 0.0; optionStrike2<=2.00; optionStrike2 += 0.001) {
			optionStrike = optionStrike2;
			plot.setTitle("T="+optionMaturity + " K="+optionStrike + " r="+riskFreeRate + " &sigma;="+volatility);



			final int start = (int)Math.pow(2, 15)-11;
			int end = 33000;//(int)Math.pow(2, 16)+1;
			end = 36000;//(int)Math.pow(2, 16)+1;
			end = start + 22;

			final Map<String, DoubleStream> errors = getError(end+1);
			final Map<String, double[]> series = errors.entrySet().stream()
					.collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue().map(Math::abs).toArray()));

			if(false) {
				final List<Plotable2D> plotables =
						List.of(
								new PlotableFunction2D(start, end, end-start+1, new Named<>("quasi-corrected",(DoubleUnaryOperator)(x -> Math.log10(series.get("quasi-corrected")[(int)x])))),
								new PlotableFunction2D(start, end, end-start+1, new Named<>("sobol",(DoubleUnaryOperator)(x -> Math.log10(series.get("sobol")[(int)x])))),
								new PlotableFunction2D(start, end, end-start+1, new Named<>("mersenne",(DoubleUnaryOperator)(x -> Math.log10(series.get("mersenne")[(int)x])))),
								new PlotableFunction2D(start, end, end-start+1, new Named<>("quasi",(DoubleUnaryOperator)(x -> Math.log10(series.get("quasi")[(int)x]))))
								);
				plot.update(plotables);
			}

			final List<Plotable2D> plotables =
					List.of(
							new PlotableFunction2D(start, end, end-start+1, new Named<>("quasi-corrected",(DoubleUnaryOperator)(x -> Math.log10(series.get("quasi-corrected")[(int)x])))),
							new PlotableFunction2D(start, end, end-start+1, new Named<>("sobol-corrected",(DoubleUnaryOperator)(x -> Math.log10(series.get("sobol-corrected")[(int)x])))),
							new PlotableFunction2D(start, end, end-start+1, new Named<>("sobol",(DoubleUnaryOperator)(x -> Math.log10(series.get("sobol")[(int)x])))),
							new PlotableFunction2D(start, end, end-start+1, new Named<>("mersenne",(DoubleUnaryOperator)(x -> Math.log10(series.get("mersenne")[(int)x])))),
							new PlotableFunction2D(start, end, end-start+1, new Named<>("quasi",(DoubleUnaryOperator)(x -> Math.log10(series.get("quasi")[(int)x]))))
							);
			plot.update(plotables);
			//			plot.saveAsPDF(new File("MC-Integration-Plot-strike-" + String.format("%1.3f", optionStrike) + ".pdf"), 900, 600);
			plot.saveAsJPG(new File("MC-Integration-Plot-strike-" + String.format("%1.3f", optionStrike) + ".jpg"), 900, 600);
		}


	}

	static Map<String, DoubleStream> getError(int numberOfPaths) {

		final Map<String, DoubleStream> error = new HashMap<>();

		final double blackScholesAnalytic = AnalyticFormulas.blackScholesOptionValue(initialValue, riskFreeRate, volatility, optionMaturity, optionStrike);

		final DoubleStream blackScholesQuasi = IntStream.range(0, numberOfPaths)
				.mapToDouble(i -> VanDerCorputSequence.getVanDerCorputNumber(i, 2))
				.map(MonteCarloQuasiBlackScholes::payoff)
				.sequential()
				.map(new Aggregator())
				.map(x -> x-blackScholesAnalytic);
		error.put("quasi", blackScholesQuasi);

		final MersenneTwister mersenne = new MersenneTwister(3141);
		final DoubleStream blackScholesMersenne = DoubleStream.generate(mersenne).limit(numberOfPaths).parallel()
				.map(MonteCarloQuasiBlackScholes::payoff)
				.sequential()
				.map(new Aggregator())
				.map(x -> x-blackScholesAnalytic);
		error.put("mersenne", blackScholesMersenne);

		final SobolSequenceGenerator generator = new SobolSequenceGenerator(1);
		//		generator.nextVector();
		final DoubleStream blackScholesSobol = DoubleStream.generate(() -> generator.nextVector()[0]).limit(numberOfPaths).parallel()
				.map(MonteCarloQuasiBlackScholes::payoff)
				.sequential()
				.map(new Aggregator())
				.map(x -> x-blackScholesAnalytic);
		error.put("sobol", blackScholesSobol);

		final DoubleStream blackScholesCenteredEqui = IntStream.range(0, numberOfPaths).parallel()
				.mapToDouble(i -> (i+0.5)/numberOfPaths)
				.map(MonteCarloQuasiBlackScholes::payoff)
				.sequential()
				.map(new Aggregator())
				.map(x -> x-blackScholesAnalytic);
		error.put("equidistributed", blackScholesCenteredEqui);

		final double[] blackScholesQuasiArray = IntStream.range(0, numberOfPaths)
				.mapToDouble(i -> VanDerCorputSequence.getVanDerCorputNumber(i, 2))
				.map(MonteCarloQuasiBlackScholes::payoff)
				.sequential()
				.map(new Aggregator())
				.map(x -> x-blackScholesAnalytic).toArray();

		final SobolSequenceGenerator generator2 = new SobolSequenceGenerator(1);
		generator2.nextVector();
		final double[] blackScholesSobolArray = DoubleStream.generate(() -> generator2.nextVector()[0]).limit(numberOfPaths).parallel()
				.map(MonteCarloQuasiBlackScholes::payoff)
				.sequential()
				.map(new Aggregator())
				.map(x -> x-blackScholesAnalytic).toArray();

		final DoubleStream blackScholesQuasiCorr = IntStream.range(1, numberOfPaths+1).mapToDouble(
				n -> {
					final double blackScholesQuasi2 = blackScholesQuasiArray[n-1];
					double blackScholesQuasiCorr1 = blackScholesQuasi2 * n/(n);
					blackScholesQuasiCorr1 += payoff(1-1.0/((2*n)))/2/(n);
					blackScholesQuasiCorr1 += payoff(0+1.0/((2*n)))/2/(n);

					double blackScholesQuasiCorr2 = blackScholesQuasi2 * n/(n-1);
					blackScholesQuasiCorr2 -= payoff(1-1.0/((n)))/2/(n-1);
					blackScholesQuasiCorr2 -= payoff(0+1.0/((n)))/2/(n-1);
					blackScholesQuasiCorr2 += payoff(1-1.0/((2*n)))/(n);
					blackScholesQuasiCorr2 += payoff(0+1.0/((2*n)))/(n);

					return blackScholesQuasiCorr2;
				}
				);
		error.put("quasi-corrected", blackScholesQuasiCorr);

		final DoubleStream blackScholesSobolCorr = IntStream.range(1, numberOfPaths+1).mapToDouble(
				n -> {
					final double blackScholesQuasi2 = blackScholesSobolArray[n-1];
					double blackScholesQuasiCorr1 = blackScholesQuasi2 * n/(n);
					blackScholesQuasiCorr1 += payoff(1-1.0/((2*n)))/2/(n);
					blackScholesQuasiCorr1 += payoff(0+1.0/((2*n)))/2/(n);

					double blackScholesQuasiCorr2 = blackScholesQuasi2 * n/(n-1);
					blackScholesQuasiCorr2 -= payoff(1-1.0/((n)))/2/(n-1);
					blackScholesQuasiCorr2 -= payoff(0+1.0/((n)))/2/(n-1);
					blackScholesQuasiCorr2 += payoff(1-1.0/((2*n)))/(n);
					blackScholesQuasiCorr2 += payoff(0+1.0/((2*n)))/(n);

					return blackScholesQuasiCorr2;
				}
				);
		error.put("sobol-corrected", blackScholesSobolCorr);

		/*
		System.out.println(numberOfPaths + "" +
				(blackScholesQuasi-blackScholesAnalytic) + "\t" +
				(blackScholesSobol-blackScholesAnalytic) + "\t" +
				(blackScholesCenteredEqui-blackScholesAnalytic) + "\t" +
				(blackScholesQuasiCorr-blackScholesAnalytic)
				);
		 */

		return error;
	}

	static double payoff(double uniform) {
		final double normalStandard = NormalDistribution.inverseCumulativeDistribution(uniform);
		final double brownian = normalStandard * Math.sqrt(optionMaturity);
		final double underlying = initialValue * Math.exp(riskFreeRate * optionMaturity
				- 0.5 * volatility * volatility * optionMaturity + volatility * brownian);
		final double payoff = Math.max(underlying-optionStrike, 0);

		return payoff * Math.exp(-riskFreeRate*optionMaturity);
	}

}
