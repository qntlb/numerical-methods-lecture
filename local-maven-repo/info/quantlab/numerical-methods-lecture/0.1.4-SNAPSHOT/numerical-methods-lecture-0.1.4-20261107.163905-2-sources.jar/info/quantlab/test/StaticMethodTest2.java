package info.quantlab.test;

import java.lang.reflect.InvocationTargetException;

public class StaticMethodTest2 extends StaticMethodTest1 {

	public static void testStatic() { System.out.println("2"); }

	public static void main(String[] args) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {

		final StaticMethodTest1 test = new StaticMethodTest2();

		final Class<? extends StaticMethodTest1> cl = test.getClass();

		cl.getMethod("testStatic").invoke(null); // Prints 2

		test.test();							// Prints 1
	}
}
