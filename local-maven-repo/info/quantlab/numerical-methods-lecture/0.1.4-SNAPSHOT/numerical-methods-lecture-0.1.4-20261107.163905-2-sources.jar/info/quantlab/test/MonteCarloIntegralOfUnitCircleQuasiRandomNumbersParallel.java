package info.quantlab.test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.DoubleUnaryOperator;
import java.util.stream.DoubleStream;

import net.finmath.randomnumbers.MersenneTwister;
import net.finmath.randomnumbers.RandomNumberGenerator1D;

public class MonteCarloIntegralOfUnitCircleQuasiRandomNumbersParallel {

	public static void main(String[] args) throws InterruptedException, ExecutionException {

		final long numberOfSimulations = 100000000L;
		final long numberOfTask = 10;
		final long numberOfSimulationPerTask = numberOfSimulations / numberOfTask;


		final long calulationMillisStart = System.currentTimeMillis();

		System.out.print("Distributing tasks");

		final List<Future<Double>> results = new ArrayList<>();
		final ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());


		final double lowerBound = 1.0;
		final double upperBound = 5.0;
		final DoubleUnaryOperator integrand = x -> Math.cos(x);
		final RandomNumberGenerator1D randomNumberGenerator = new MersenneTwister(3141);
		final double range = upperBound-lowerBound;
		for(long taskIndex = 0; taskIndex<numberOfTask; taskIndex++) {

			final Callable<Double> task = new Callable<>() {
				@Override
				public Double call() throws Exception {
					final DoubleStream randomNumbers = DoubleStream.generate(randomNumberGenerator).limit(numberOfSimulationPerTask);

					final double sum = randomNumbers.map(x -> integrand.applyAsDouble(lowerBound+range*x)).sum();

					return sum/numberOfSimulationPerTask * range;
				}
			};

			final Future<Double> integral = executor.submit(task);

			results.add(integral);
		}
		System.out.println("done.");

		/*
		 * All task started. Now wait for the results.
		 */

		System.out.print("Collecting results");

		double piApprox = 0.0;
		for(int taskIndex = 0; taskIndex<numberOfTask; taskIndex++) {
			System.out.print(".");

			final Future<Double> piArroxInTask = results.get(taskIndex);
			piApprox += piArroxInTask.get();
		}
		piApprox = piApprox /numberOfTask;
		System.out.println("done.");


		final long calulationMillisEnd = System.currentTimeMillis();

		final double calculationTimeSec = (calulationMillisEnd-calulationMillisStart) / 1000.0;

		final double pi = Math.PI;

		final double error = piApprox - pi;

		System.out.println("Approximation of pi via Quasi-Monte-Carlo.....: " + piApprox);
		System.out.println("Approximation error -.........................: " + error);
		System.out.println("Theoretical Monte-Carlo error O-of............; " + 1.0/Math.sqrt(numberOfSimulations));
		System.out.println("Theoretical Halton-Seq. error O-of............; " + (Math.pow(Math.log(numberOfSimulations),2)/numberOfSimulations));
		System.out.println("Calculation time..............................; " + calculationTimeSec + " sec.");
	}


}
