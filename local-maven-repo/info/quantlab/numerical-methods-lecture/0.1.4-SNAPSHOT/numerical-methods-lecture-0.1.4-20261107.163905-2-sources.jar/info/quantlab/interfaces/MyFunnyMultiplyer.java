package info.quantlab.interfaces;

public class MyFunnyMultiplyer implements Multiplyer {

	@Override
	public double multiply(double a, double b) {
		return a * b;
	}
}
