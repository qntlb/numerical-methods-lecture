/**
 * Differential operator interfaces.
 *
 * @author Christian Fries
 */
package info.quantlab.interfaces.differential;
