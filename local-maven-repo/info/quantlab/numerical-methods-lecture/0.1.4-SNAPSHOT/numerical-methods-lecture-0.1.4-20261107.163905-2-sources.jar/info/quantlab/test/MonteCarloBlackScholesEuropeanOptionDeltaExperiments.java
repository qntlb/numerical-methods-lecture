package info.quantlab.test;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;
import java.util.function.DoubleUnaryOperator;

import net.finmath.exception.CalculationException;
import net.finmath.functions.AnalyticFormulas;
import net.finmath.montecarlo.BrownianMotion;
import net.finmath.montecarlo.BrownianMotionFromMersenneRandomNumbers;
import net.finmath.montecarlo.assetderivativevaluation.AssetModelMonteCarloSimulationModel;
import net.finmath.montecarlo.assetderivativevaluation.MonteCarloAssetModel;
import net.finmath.montecarlo.assetderivativevaluation.models.BlackScholesModel;
import net.finmath.montecarlo.process.EulerSchemeFromProcessModel;
import net.finmath.montecarlo.process.MonteCarloProcess;
import net.finmath.plots.Plot2D;
import net.finmath.plots.PlotableFunction2D;
import net.finmath.stochastic.RandomOperator;
import net.finmath.stochastic.RandomVariable;
import net.finmath.stochastic.Scalar;
import net.finmath.time.TimeDiscretizationFromArray;

public class MonteCarloBlackScholesEuropeanOptionDeltaExperiments {

	private static double initialValue = 100.0;
	private static int seed = 3216;

	public static void main(String[] args) throws Exception {

		final double riskFreeRate = 0.05;
		final double volatility = 0.30;

		final double maturity = 5.0;
		final double strike = 125.0;

		final double timeHorizon = maturity;
		final double dt = 5.0;
		final int numberOfPath = 10000;	// may try 100,000

		final MonteCarloAssetModel model = getModel(initialValue, riskFreeRate, volatility, timeHorizon, dt, numberOfPath);

		final RandomOperator payoffZero = underlying -> new Scalar(0.0);
		final RandomOperator payoffBond = underlying -> new Scalar(1.0);
		final RandomOperator payoffForward = underlying -> underlying;
		final RandomOperator payoffOption = underlying -> underlying.sub(strike).floor(0.0);
		final RandomOperator payoffDigital = underlying -> underlying.sub(strike).choose(new Scalar(1.0), new Scalar(0.0));

		System.out.format("%-24s\t%-10s\t%-10s\t%-10s\n", "", "Monte-Carlo", "Analytic", "Error");

		final double valueAnalytic = AnalyticFormulas.blackScholesOptionValue(initialValue, riskFreeRate, volatility, maturity, strike);
		final double valueMonteCarlo = getValueMonteCarlo(model, maturity, payoffOption);
		printResult("Valuation...:", valueMonteCarlo, valueAnalytic);

		System.out.println("\nBond:");
		final double deltaBondAnalytic = 0.0;
		checkDeltaApproximationErrors(model, maturity, payoffBond, payoffZero, deltaBondAnalytic);

		System.out.println("\nForward:");
		final double deltaForwardAnalytic = 1.0;
		checkDeltaApproximationErrors(model, maturity, payoffForward, payoffBond, deltaForwardAnalytic);

		System.out.println("\nEuropean Option:");
		final double deltaAnalytic = AnalyticFormulas.blackScholesOptionDelta(initialValue, riskFreeRate, volatility, maturity, strike);
		checkDeltaApproximationErrors(model, maturity, payoffOption, payoffDigital, deltaAnalytic);

		System.out.println("\nDigital Option:");
		final double deltaDigitalAnalytic = AnalyticFormulas.blackScholesDigitalOptionDelta(initialValue, riskFreeRate, volatility, maturity, strike);
		checkDeltaApproximationErrors(model, maturity, payoffDigital, x -> new Scalar(Double.NaN), deltaDigitalAnalytic);

		getPlotOfFiniteDifferenceApproxByShift(0, 8, model, maturity, payoffForward)
		.setTitle("Finite Difference Approximation of Delta of Forward").setXAxisLabel("scale (shift = S(0)*10^{-scale})").setYAxisLabel("value").setYAxisNumberFormat(new DecimalFormat("0.#####")).show();

		getPlotOfFiniteDifferenceApproxByShift(0, 12, model, maturity, payoffOption)
		.setTitle("Finite Difference Approximation of Delta of European Option").setXAxisLabel("scale (shift = S(0)*10^{-scale})").setYAxisNumberFormat(new DecimalFormat("0.#####")).setYAxisLabel("value").show();

		// try 10,15, try 10,17, try 0,5, try with more or less paths
		getPlotOfFiniteDifferenceApproxByShift(2, 12, model, maturity, payoffOption)
		.setTitle("Finite Difference Approximation of Delta of European Option").setXAxisLabel("scale (shift = S(0)*10^{-scale})").setYAxisLabel("value").setYAxisNumberFormat(new DecimalFormat("0.#####")).show();

		getPlotOfFiniteDifferenceApproxByShift(2, 8, model, maturity, payoffDigital)
		.setTitle("Finite Difference Approximation of Delta of Digital Option").setXAxisLabel("scale (shift = S(0)*10^{-scale})").setYAxisLabel("value").setYAxisNumberFormat(new DecimalFormat("0.#####")).show();
	}

	private static void checkDeltaApproximationErrors(MonteCarloAssetModel model, double maturity, RandomOperator payoffFunction, RandomOperator payoffFunctionDerivative, double valueAnalytic) throws CalculationException {
		final double deltaFiniteDifference1 = getDeltaFiniteDifference(model, maturity, payoffFunction, 0.1);
		printResult("Finite Diff h=1e-1:", deltaFiniteDifference1, valueAnalytic);

		final double deltaFiniteDifference3 = getDeltaFiniteDifference(model, maturity, payoffFunction, 0.001);
		printResult("Finite Diff h=1e-3:", deltaFiniteDifference3, valueAnalytic);

		final double deltaPathwise = getDeltaPathwiseDifferentiation(model, maturity, payoffFunctionDerivative);
		printResult("Pathwise Diff:", deltaPathwise, valueAnalytic);

		final double deltaLikelihood = getDeltaLikelihoodRatio(model, maturity, payoffFunction);
		printResult("Likelihood Ratio:", deltaLikelihood, valueAnalytic);
	}

	private static void printResult(String name, double value, double valueAnalytic) {
		System.out.format("%24s\t%+10.6f\t%+10.6f\t%+12.5e\n", name, value, valueAnalytic, value-valueAnalytic);
	}

	private static Plot2D getPlotOfFiniteDifferenceApproxByShift(double xmin, double xmax, MonteCarloAssetModel model, double maturity, RandomOperator payoffFunction) {
		final DoubleUnaryOperator deltaFinDifByShift = scale -> getDeltaFiniteDifference(
				model, maturity, payoffFunction, initialValue*Math.pow(10, -scale) /* shift */);
		return new Plot2D(List.of(new PlotableFunction2D(xmin, xmax, 400, deltaFinDifByShift)));
	}

	private static MonteCarloAssetModel getModel(double initialValue, double riskFreeRate, double volatility, double timeHorizon, double dt, int numberOfPath) {

		final BlackScholesModel blackScholesModel = new BlackScholesModel(initialValue, riskFreeRate, volatility);
		final BrownianMotion bm = new BrownianMotionFromMersenneRandomNumbers(new TimeDiscretizationFromArray(0.0, (int)Math.round(timeHorizon/dt), dt), 1, numberOfPath, seed);
		final MonteCarloProcess process = new EulerSchemeFromProcessModel(blackScholesModel, bm);
		return new MonteCarloAssetModel(process);
	}

	private static double getValueMonteCarlo(AssetModelMonteCarloSimulationModel model, double maturity, RandomOperator payoffFunction) throws CalculationException {

		final var underlying = model.getAssetValue(maturity, 0);
		final var payoff = payoffFunction.apply(underlying);
		final var value = payoff.div(model.getNumeraire(maturity)).mult(model.getNumeraire(0.0));

		return value.average().doubleValue();
	}

	private static double getDeltaFiniteDifference(MonteCarloAssetModel model, double maturity, RandomOperator payoffFunction, double shift) {
		try {
			final double valueUp = getValueMonteCarlo(model.getCloneWithModifiedData(Map.of("initialValue", initialValue + shift)), maturity, payoffFunction);
			final double valueDn = getValueMonteCarlo(model.getCloneWithModifiedData(Map.of("initialValue", initialValue - shift)), maturity, payoffFunction);
			return (valueUp - valueDn) / (2*shift);
		} catch (final CalculationException e) {
			return Double.NaN;
		}
	}

	private static double getDeltaPathwiseDifferentiation(MonteCarloAssetModel model, double maturity, RandomOperator payoffFunctionDerivative) throws CalculationException {
		final var underlying = model.getAssetValue(maturity, 0);

		final var payoffDerivative = payoffFunctionDerivative.apply(underlying);
		final var payoffDerivativeWeighted = payoffDerivative.mult(underlying.div(model.getAssetValue(0.0, 0)));

		final var value = payoffDerivativeWeighted.div(model.getNumeraire(maturity)).mult(model.getNumeraire(0.0));

		return value.average().doubleValue();
	}

	private static double getDeltaLikelihoodRatio(MonteCarloAssetModel model, double maturity, RandomOperator payoffFunction) throws CalculationException {
		final var underlying = model.getAssetValue(maturity, 0);

		final var payoff = payoffFunction.apply(underlying);
		final var payoffWeighted = payoff.mult(getLikelihoodRatio(model, maturity));

		final var value = payoffWeighted.div(model.getNumeraire(maturity)).mult(model.getNumeraire(0.0));

		return value.average().doubleValue();
	}

	private static RandomVariable getLikelihoodRatio(MonteCarloAssetModel model, double maturity) throws CalculationException {
		final var underlyingAtMaturity = model.getAssetValue(maturity, 0);
		final var underlyingAtToday = model.getAssetValue(0.0, 0);

		final BlackScholesModel blackScholesModel = (BlackScholesModel)model.getModel();
		final var r = blackScholesModel.getRiskFreeRate();
		final var sigma = blackScholesModel.getVolatility();
		final var T = maturity;

		final RandomVariable WT = underlyingAtMaturity.div(underlyingAtToday).log().sub(r.mult(T).sub(sigma.squared().mult(0.5*T)));
		final var likelihoodRatio = WT.div(underlyingAtToday).div(sigma.squared()).div(T);
		return likelihoodRatio;
	}
}
