package info.quantlab.test;

import java.text.DecimalFormat;
import java.util.function.DoubleUnaryOperator;

import net.finmath.plots.Plot2D;

public class FiniteDifferenceExperiments {

	public static void main(String[] args) {

		final double x = 0.0;

		printForwardFiniteDifferenceApproximationOfExp(x, 0.01 /* shift */);
		printForwardFiniteDifferenceApproximationOfExp(x, 0.0001 /* shift */);

		printForwardFiniteDifferenceApproximationOfExp(x, 1E-15 /* shift */);
		printForwardFiniteDifferenceApproximationOfExp(x, 1E-16 /* shift */);
		printForwardFiniteDifferenceApproximationOfExp(x, 1E-12 /* shift */);
		printForwardFiniteDifferenceApproximationOfExp(x, Math.pow(2, -52) /* shift */);
		printForwardFiniteDifferenceApproximationOfExp(x, 1.5*Math.pow(2, -52) /* shift */);

		//		plotForwardFiniteDifferenceApproximationErrorOfExp(x);
	}

	private static void plotForwardFiniteDifferenceApproximationErrorOfExp(double x) {

		final DoubleUnaryOperator finiteDifferenceApproxError = scale -> {

			final double shift = Math.pow(10, -scale);

			final double valueUpShift = Math.exp(x+shift);
			final double value = Math.exp(x);
			final double finiteDifferenceApproximation = (valueUpShift-value) / shift;

			final double derivativeAnalytic = Math.exp(x);

			final double error = finiteDifferenceApproximation - derivativeAnalytic;

			return error;
		};

		final Plot2D plot = new Plot2D(14, 16.5, 200, finiteDifferenceApproxError);
		plot.show();
		plot.setTitle("(One Sided Finite Differnce) Derivative of exp(x)")
		.setXAxisLabel("scale (h = 10^{-scale}")
		.setYAxisLabel("error")
		.setYAxisNumberFormat(new DecimalFormat("0E00"));

	}

	private static void printForwardFiniteDifferenceApproximationOfExp(double x, double shift) {

		final double valueUpShift = Math.exp(x+shift);
		final double value = Math.exp(x);
		final double finiteDifferenceApproximation = (valueUpShift-value) / shift;

		System.out.println("h = " + shift + "  \t finiteDifferenceApproximation = " + finiteDifferenceApproximation);

	}

}
