package info.quantlab.test;

import java.util.ArrayList;
import java.util.List;

import net.finmath.plots.Plot2D;
import net.finmath.plots.Plots;
import net.finmath.randomnumbers.MersenneTwister;

public class MersenneSequenceTest {

	/*
	 * Test seed for Random 3636 then Position 3614 for nextFloat is zero.
	 */
	public static void main(String[] args) throws Exception {

		final MersenneTwister uniform = new MersenneTwister();

		final org.apache.commons.math3.distribution.NormalDistribution normal =
				new org.apache.commons.math3.distribution.NormalDistribution();

		final List<Double> values = new ArrayList<>();

		for(int i=0; i<100000; i++) {
			final double uniformNumber = uniform.nextDouble();

			final double normalFromUniform = normal.inverseCumulativeProbability(uniformNumber);
			System.out.println(i + "\t" + uniformNumber + "\t\t" + normalFromUniform);

			values.add(normalFromUniform);
		}

		final Plot2D plot = Plots.createHistogram(values, 100, 4.0);
		plot.setTitle(uniform.getClass().getSimpleName());
		plot.show();

	}
}
